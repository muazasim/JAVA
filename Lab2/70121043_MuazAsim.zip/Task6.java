import java.util.Scanner;
import java.lang.Math;
class Task6{
	public static void main (String Args[]){
	
	double ans;
	 int num =7;
	 int num2 =5;
	 ans=Math.pow(num,num2);
	 System.out.println(ans);

}
}
