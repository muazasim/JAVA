public class Task1{
    public static void main(String Args[]){

        // BITWISE OPERATORS >>>>>>>>>>>>>>
        // Bitwise operators in java
        // these operators are used to maniuplate the input/variables in 
        int x = 5;
        int y = 7;
        System.out.println(x|y);
         System.out.println(x&y);
          System.out.println(~x);
           System.out.println(x^y);
    }
}