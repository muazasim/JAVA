public class Taks11 {
    public static void main(String arg[])
    {
        for (int i= 0 ; i<5 ; i++ ){
            if (i==0){
                
                System.out.println(" +\"\"\"\"\"+ ");

            }
            else if (i==1){
                System.out.println("[| o o |] ");

            }
              else if (i==2){
                System.out.println(" |  ^  |  ");

            }
              else if (i==3){
                System.out.println(" | '-' | ");

            }
              else{
                System.out.println(" +-----+ ");

            }
        }

    }
}
