import java.util.Scanner;
class Task4{
	public static void main (String Args[]){
	
	 int num =2345;
	 num=num+8;
	 num=num/3;
	 num=num%5;
	 num=num*5;
	 System.out.println(num);

}
}
