public class Task8 {

    public static void main(String ARGS[]){
       double Students =90;
       double Atsds= 50;
       double boys=20;

       double girls= (Students/2) ; 
       girls=boys/girls * 50; // percentage of boys with A grade 
       girls= Atsds - girls; // percentage of Girls with A grade 
       girls= girls / 50 *45 ; // no of girls with A grade 
       System.out.println("total no of girls with A grade : "+girls);   



    }
    
}
