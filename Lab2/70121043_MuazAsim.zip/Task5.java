import java.util.Scanner;
class Task5{
	public static void main (String Args[]){
	
	 int num =2345;
	 num+=8;
	 num/=3;
	 num%=5;
	 num*=5;
	 System.out.println(num);

}
}
