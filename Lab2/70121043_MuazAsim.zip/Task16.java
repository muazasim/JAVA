import java.util.Scanner;
public class Task16 {
    public static void main(String Args[])
    {
        int number;
        Scanner c = new Scanner(System.in);
        do {
            System.out.println("Enter Number");
            number= c.nextInt();
            
        } while (number!=-1);
        




    }
    
}

