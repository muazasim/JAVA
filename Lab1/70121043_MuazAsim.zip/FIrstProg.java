public class FIrstProg {
    public static void main (String a[]){
    System.out.println("I LOVE JAVA");
}

}