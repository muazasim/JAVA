import java.util.Scanner;

public class Triangle {

    public static void main (String a[]){
    
       
        // Without User input 
            for (int i = 5 ; i>=0 ; i--)
            {
                for (int j = i ; j>=0 ; j--){
                    System.out.print("*");
                }
                System.out.println(" ");
            }
        
           }
    

    // rows and coloums from user
    // Scanner c = new Scanner (System.in);
    // System.out.println("Enter no of Rows");
    // int rows= c.nextInt();
    // System.out.println("Enter no of Colums");
    // int col= c.nextInt();
    //    for (int i = rows; i>=0 ; i--)
    //     {
    //         for (int j = i ; j>=0 ; j--){
    //             if(j<col){
    //                  System.out.print("*");
    //             }
               
    //         }
    //         System.out.println(" ");
    //     }
    

    //    } 


    
    
}
